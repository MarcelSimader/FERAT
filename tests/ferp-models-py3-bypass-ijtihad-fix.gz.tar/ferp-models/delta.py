#!/usr/bin/python2
import os, sys, shutil, subprocess

home = os.path.dirname(os.path.abspath(__file__)) + "/"
pipeline = home + "pipeline.py"

assert(len(sys.argv) == 2)
FOUT = open(home + "tmp/out.txt", "wb")
subprocess.call(["python", pipeline, sys.argv[1], home + "tmp/tmp.aig"], stdout=FOUT)
FOUT.close()
with open(home + "tmp/out.txt", "rb") as FOUT:
  tmp_str = FOUT.read()
# if "SUCCESS" in tmp_str: print "SUCCESS"
# if "TRUE" in tmp_str: print "TRUE"
# if "FAILED" in tmp_str: print "FAILED"
if "Check validity of certificate ... FAILED" in tmp_str: 
  #print tmp_str
  sys.exit(1)
sys.exit(0)
