import os, sys, shutil, subprocess

home = os.path.dirname(os.path.abspath(__file__)) + "/"

fuzzer = home + "qbfuzz-1.1.1/qbfuzz.py"
pipeline = home + "pipeline.py"

if "test" in os.listdir(home):
  shutil.rmtree(home + "test", ignore_errors=True)
os.makedirs(home + "test")

for i in range(0, 1000):
  print "Running test", i
  while True:
    subprocess.call(["python3", fuzzer, "-v", "50", "--min", "5",      "--max", "5", "-o", home + ("test/test-%d.qbf" % i)])
    if os.path.exists(("test/test-%d.qbf" % i)): break
  
  with open(home + ("test/out-%d.txt" % i), "wb") as FOUT:
    subprocess.call(["python", pipeline, home + ("test/test-%d.qbf" % i), home + ("test/test-%d.aig" % i)], stdout=FOUT)
  with open(home + ("test/out-%d.txt" % i), "rb") as FOUT:
    tmp_str = FOUT.read()
  if "SUCCESS" in tmp_str: print "SUCCESS"
  if "TRUE" in tmp_str: print "TRUE"
  if "FAILED" in tmp_str: print "FAILED"
  if "Check validity of certificate ... FAILED" in tmp_str:
    print tmp_str
    sys.exit(0)
